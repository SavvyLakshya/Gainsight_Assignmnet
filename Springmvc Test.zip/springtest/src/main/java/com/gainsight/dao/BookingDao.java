package com.gainsight.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.gainsight.entity.Flight;
import com.gainsight.entity.Passengers;

@Repository
public class BookingDao {



	
	private static String url ="jdbc:mysql://localhost:3306/employee";
	
	public Flight getFlightById(String flightId) {
	    Flight flight = null;
	    Connection conn = null;
	    PreparedStatement pst = null;
	    ResultSet rs=null;
	    try{
	        Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection(url,"root","Lakshya@12");
	        pst = conn.prepareStatement("select * from Flight where flight_id = ?");
	        pst.setString(1, flightId);


	        rs = pst.executeQuery();
	        if(rs.next())
	            flight = new Flight(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5));
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	    }
	    finally
	    {
	        try
	        {
	            if(rs!=null) rs.close();
	            if(pst!=null) pst.close();
	            if(conn!=null) conn.close();
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	    }

	    return flight;
	}

	public boolean bookFlight(String flightId, Passengers passenger, String travelDate) {
	    Connection conn = null;
	    Connection conn1 = null;
	    PreparedStatement pst = null;
	    PreparedStatement pst1 = null;
	    int count=0;
	    int count1 = 0;
	    int bookingId =  new java.util.Random().nextInt();
	    try{
	        Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection(url,"root","Lakshya@12");
	        pst = conn.prepareStatement("insert into passengers values(?,?,?,?,?)");
	        pst.setString(1, passenger.getPassengerId());
	        pst.setString(2, passenger.getFirst_name());
	        pst.setString(3, passenger.getLast_name());
	        pst.setLong(4, passenger.getMobile());
	        pst.setString(5, passenger.getEmail());

	        count = pst.executeUpdate();

	       // Class.forName("com.mysql.jdbc.Driver");
	        //conn1 = DriverManager.getConnection(url,"root","Lakshya@12");
	                pst1 = conn.prepareStatement("insert into bookings values(?,?,?,?)");
	        pst1.setInt(1, bookingId);
	        pst1.setString(2, flightId);
	        pst1.setString(3, passenger.getPassengerId());
	        pst1.setString(4, travelDate);
	        count1 = pst1.executeUpdate();



	    }
	    catch(Exception e) {
	        e.printStackTrace();
	    }
	    finally
	    {
	        try
	        {
	            if(pst!=null) pst.close();
	            if(pst1!=null) pst1.close();
	            if(conn!=null) conn.close();
	            if(conn1!=null) conn1.close();
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	    }
	    return count==1 && count1==1;
	}

}
