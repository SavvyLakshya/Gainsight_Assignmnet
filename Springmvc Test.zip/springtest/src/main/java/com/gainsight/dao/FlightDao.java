package com.gainsight.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.gainsight.entity.Flight;

@Repository

public class FlightDao {
	



	private static String url ="jdbc:mysql://localhost:3306/employee";

	public ArrayList<Flight> getFlightsBySourceAndDestination(String source, String destination)
	{
		// TODO Auto-generated method stub
		
		ArrayList<Flight> list= new ArrayList<>();
	Connection con=null;
	PreparedStatement pst =null;
	ResultSet rset=null;
	
	try
	{
		
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(url,"root","Lakshya@12");
		pst= con.prepareStatement("select * from flight where source=? and destination=?");
		
		pst.setString(1, source);
		pst.setString(2, destination);
		rset= pst.executeQuery();
		
		
		while(rset.next())
list.add(new Flight(rset.getString(1),rset.getString(2),rset.getString(3),rset.getDouble(4),rset.getInt(5)));
			
	}
	catch(Exception ex) {
		ex.printStackTrace();
		
	}
	finally {
		try {
			
			if(pst!=null) pst.close();
			if(con!=null) con.close();
		}
		catch(Exception ex) {
			ex.printStackTrace();
			
		}
	}
	return list;


}
}
