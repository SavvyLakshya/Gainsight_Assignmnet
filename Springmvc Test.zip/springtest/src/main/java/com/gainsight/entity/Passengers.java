package com.gainsight.entity;

public class Passengers {
	
	private String passengerId;
	
	private String firstName;
	
	private String lastname;
	
	private Long mobile;
	
	private String email;

	public Passengers(String passenger_id, String first_name, String last_name, Long mobile, String email) {
		super();
		this.passengerId = passenger_id;
		this.firstName = first_name;
		this.lastname = last_name;
		this.mobile = mobile;
		this.email = email;
	}

	public String getPassengerId() {
		return passengerId;
	}

	public void setPassenger_id(String passenger_id) {
		this.passengerId = passenger_id;
	}

	public String getFirst_name() {
		return firstName;
	}

	public void setFirst_name(String first_name) {
		this.firstName = first_name;
	}

	public String getLast_name() {
		return lastname;
	}

	public void setLast_name(String last_name) {
		this.lastname = last_name;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
