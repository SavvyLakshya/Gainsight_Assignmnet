package com.gainsight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gainsight.dao.BookingDao;
import com.gainsight.dao.FlightDao;
import com.gainsight.entity.Flight;
import com.gainsight.entity.Passengers;

@Controller
public class BookingController {
	
	@Autowired
	BookingDao bdao;
	
		
	
	@PostMapping("/bookFlight")
	public String bookFlightAndPassengerDetails(@RequestParam("flightId")String flightId, @RequestParam("passengerId") String passengerId, @RequestParam("firstname") String firstName, @RequestParam("lastname") String lastName, @RequestParam("mobile") long mobile, @RequestParam("email") String email, @RequestParam("traveldate") String travelDate, Model model) {
	    Passengers p = new Passengers(passengerId, firstName, lastName, mobile, email);

	    if(bdao.bookFlight(flightId,p,travelDate))
	    {
	        Flight f = bdao.getFlightById(flightId);
	        model.addAttribute("flight",f);
	        model.addAttribute("Passenger",p);
	        model.addAttribute("message","Successful;");
	        return "Display";
	    }


	    model.addAttribute("message","Not Succesful");
	    return "Display";
}

}
